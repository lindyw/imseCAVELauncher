Installation Step:

1. Install program
2. Open the program
3. Go to "Settings"
4. Tick "Start server automatically"
5. Click "SAVE"
6. Go to "Home"
7. Click "START"
8. Edit ShutDown.bat line 1 : set tracker_computer_ip_address=____:3000 (____ is the IP or Name shown in Home Page)
9. Copy the program shortcut to Startup Folder